export const firebaseConfig = {
  apiKey: "AIzaSyD_2lvix4PlFR_xwJGnbBly8iMto79FLFk",
  authDomain: "sudoku-leaderboard-22c4b.firebaseapp.com",
  projectId: "sudoku-leaderboard-22c4b",
  storageBucket: "sudoku-leaderboard-22c4b.firebasestorage.app",
  messagingSenderId: "153250752206",
  appId: "1:153250752206:web:199a785601ce6c2f90129f",
  measurementId: "G-DX1G4ZR3WE",
};
